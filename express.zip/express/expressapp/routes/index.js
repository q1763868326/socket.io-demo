var express = require('express');
var router = express.Router();
const pg = require("pg")
const {query_search,query_searchname} = require("../utils/test")

/* GET home page. */
router.get('/', async function(req, res, next) {
  try {
    search = req.query.search
    console.log(search)
    data = query_search(search)
    res.send(await data)
    // res.send(await fileinfo)
  } catch (error) {
    console.log(error)
    res.status(500).send(error)
  }
  
});

router.post('/getname',async (req,res)=>{
  try {
    var lastname = req.body.lastname;
    namelist = query_search(lastname)
    res.send(await namelist)
  } catch (error) {
    console.log(error)
    res.status(400).send(error)
  }
})

async function searchname(lastname){

}

module.exports = router;
