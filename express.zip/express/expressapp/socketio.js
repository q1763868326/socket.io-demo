var socket_io = require("socket.io")
var fs = require("fs")
var socketio = {}

socketio.getsocketio = (server)=>{
    var io = socket_io.listen(server)

    io.on("connection",(socket)=>{
       socket.on("message",data=>{
           console.log(data.file)
       })
    //    io.emit('server message', {msg:'client connect server success'});
       socket.on("disconnect",()=>{
           console.log("disconnect")
       }) 

       socket.on('close',()=>{
           socket.disconnect()
       })

       socket.on('imgsend',(data)=>{
           var imgdata = data.img;
           var base64Data = imgdata.replace(/^data:image\/\w+;base64,/, "");
           var dataBuffer = new Buffer.from(base64Data, 'base64');
           fs.writeFile("socket.jpg",dataBuffer,(err)=>{
               if(err){
                   console.log(err)
               }
               else{
                   console.log("保存成功")
               }
           })
       })
    
    })
}

module.exports = socketio