const axios = require('axios')

const request = require('request');
  
// request('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY', { json: true }, (err, res, body) => {
//  if (err) { return console.log(err); }
//  console.log(body.url);
//  console.log(body.explanation);
// });


axios.post("http://127.0.0.1:3000/getname",{"lastname":"朱"}).then(res=>{
    console.log(res.data)
}).catch(error=>{
    console.log(error)
})
console.log("success")