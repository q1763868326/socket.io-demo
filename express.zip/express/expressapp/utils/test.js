var pg =require('pg');
const { search } = require('../routes');
// var fs = require("fs")

var config = {
    host:"116.62.47.156",
    user:"root",
    database:"root",
    password:"q9685481281.",
    port:5432,
 // 扩展属性
    max:20, // 连接池最大连接数
    idleTimeoutMillis:3000, // 连接最大空闲时间 3s
}
var pool = new pg.Pool(config);

exports.query_searchname = async (search)=>{
    if(search=='')
        return "error"
    search = search+'%'
try {
    var client = await pool.connect();
    var res = await client.query("SELECT * FROM public.studentinfo where studentname like $1 ORDER BY studentname ASC",[search])
    if(res.rows.length==0){
        return "null"
    }
        return res.rows
    } catch (error) {
        console.log(error)
    }
    finally{
        client.release();
    }
}
// console.log(pool)
exports.query_search = async (search)=>{
    if(search=='')
        return "error"
    search = '%'+search+'%'
    try {
        var client = await pool.connect();
        var res = await client.query("SELECT (studentname) FROM public.studentinfo where studentname like $1 ORDER BY studentname ASC",[search])
        if(res.rows.length==0){
            return "null"
        }
        return res.rows
    } catch (error) {
        console.log(error)
    }
    finally{
        client.release();
    }
}
// var question = "这道题你会吗？"
// var anwser = "会的"
// var insert = async (question,anwser)=>{
//     try {
//         var client = await pool.connect();
//         res = await client.query("INSERT INTO public.question_anwser(question, anwser) VALUES ($1, $2);",[question,anwser]);
//         test = await new Promise(
//             (resolve)=>{
//                 resolve(res.rowCount)
//             }
//         ) 
//         console.log(test)
//     } catch (error) {
//         console.log(error)
//     }
//     finally{
//         client.release();
//     }
// }

// var query_delete = async ()=>{
//     var client = await pool.connect()
//     res = await client.query("DELETE FROM question_anwser where question is null")
//     console.log(res.rowCount)
//     client.release()
// }

// var query_update = async ()=>{
//     var client = await pool.connect()
//     res = await client.query("UPDATE question_anwser set anwser=$1",["不会"])
//     console.log(res.rowCount)
//     client.release()
// }
// insert(question,anwser).then(query).then(query_delete).then(query_update).then(query)


// exports.Loadfile = ()=>{
//     return new Promise((resolve,reject)=>{
//         fs.readFile("../test.pdf",(err,data)=>{
//             if(err){
//                 reject(err)
//             }else{
//                 console.log("success")
//                 resolve(data.toString())
//             }
//         })
//     })
// }

