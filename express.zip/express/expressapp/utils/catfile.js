const fs = require("fs")
const readline = require("readline")


function readFileToArr(fReadName,callback){
    var fRead =  fs.createReadStream(fReadName);
    var objReadline = readline.createInterface({
        input:fRead
    });
    var arr = new Array();
    var num = 10;
    objReadline.on('line',function (line) {
        if(num>0){
            console.log(line);
            num--;
        }
        else{
            fRead.close()
        }
        
    });
    objReadline.on('close',function () {
       // console.log(arr);
        callback(arr);
    });
}

readFileToArr("./input.txt")